# =============================================================================
# SINGLE-CELL COLAB RUNNER
# Copy-paste this whole cell into a Google Colab notebook and run it.
# Replace YOUR_USERNAME below with your actual GitHub username.
# =============================================================================

REPO_URL = "https://github.com/YOUR_USERNAME/hybrid-tft-tabnet-cad-detection.git"

import subprocess, sys, os

# 1. Clone the repo (skip if already cloned)
if not os.path.exists("hybrid-tft-tabnet-cad-detection"):
    subprocess.run(["git", "clone", REPO_URL], check=True)
os.chdir("hybrid-tft-tabnet-cad-detection")

# 2. Install dependencies
subprocess.run([sys.executable, "-m", "pip", "install", "-q", "-r", "requirements.txt"], check=True)

# 3. Run training
#    --use_low_res gives a quick smoke test on the 100Hz records first;
#    remove it for the full 500Hz run reported in the paper.
subprocess.run([
    sys.executable, "src/train.py",
    "--data_root", "/content/ptbxl_data",
    "--out_dir", "/content/outputs",
    "--epochs", "50",
    "--n_folds", "5",
    "--use_low_res",   # <-- remove this line for the full paper-matching run
], check=True)

# 4. Generate the publication figures from the real predictions just produced
subprocess.run([sys.executable, "src/plots.py", "--out_dir", "/content/outputs"], check=True)

print("Done. Check /content/outputs/figures for the plots and "
      "/content/outputs/test_predictions.npz for raw predictions.")

"""
Generates the publication figures from REAL saved model outputs
(train.py's test_predictions.npz and fold_metrics.json) -- nothing here
is hardcoded; every figure is computed from actual predictions.

Run after train.py:
    python src/plots.py --out_dir ./outputs
"""

import os
import json
import argparse
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, precision_recall_curve, confusion_matrix, auc


def plot_confusion_matrix(y_true, probs, out_path, threshold=0.5):
    preds = (probs >= threshold).astype(int)
    cm = confusion_matrix(y_true, preds)
    fig, ax = plt.subplots(figsize=(5, 4.5))
    im = ax.imshow(cm, cmap="Blues")
    for i in range(2):
        for j in range(2):
            ax.text(j, i, str(cm[i, j]), ha="center", va="center", fontsize=14)
    ax.set_xticks([0, 1]); ax.set_yticks([0, 1])
    ax.set_xticklabels(["CAD-negative", "CAD-positive"])
    ax.set_yticklabels(["CAD-negative", "CAD-positive"])
    ax.set_xlabel("Predicted"); ax.set_ylabel("True")
    ax.set_title("Confusion Matrix (Held-Out Test Set)")
    fig.colorbar(im)
    fig.tight_layout()
    fig.savefig(out_path, dpi=300)
    plt.close(fig)


def plot_roc(y_true, probs, out_path):
    fpr, tpr, _ = roc_curve(y_true, probs)
    roc_auc = auc(fpr, tpr)
    fig, ax = plt.subplots(figsize=(5, 4.5))
    ax.plot(fpr, tpr, label=f"AUC = {roc_auc:.4f}")
    ax.plot([0, 1], [0, 1], linestyle="--", color="gray")
    ax.set_xlabel("False Positive Rate"); ax.set_ylabel("True Positive Rate")
    ax.set_title("ROC Curve (Ensemble, Test Set)")
    ax.legend(loc="lower right")
    fig.tight_layout()
    fig.savefig(out_path, dpi=300)
    plt.close(fig)


def plot_pr_curve(y_true, probs, out_path):
    precision, recall, _ = precision_recall_curve(y_true, probs)
    ap = np.trapz(precision[::-1], recall[::-1])
    fig, ax = plt.subplots(figsize=(5, 4.5))
    ax.plot(recall, precision, label=f"AP = {ap:.4f}")
    ax.set_xlabel("Recall (Sensitivity)"); ax.set_ylabel("Precision")
    ax.set_title("Precision-Recall Curve (Ensemble, Test Set)")
    ax.legend(loc="lower left")
    fig.tight_layout()
    fig.savefig(out_path, dpi=300)
    plt.close(fig)


def plot_fold_bars(fold_metrics, out_path):
    keys = ["accuracy", "f1", "auc", "sensitivity", "specificity"]
    folds = list(range(1, len(fold_metrics) + 1))
    fig, ax = plt.subplots(figsize=(7, 4.5))
    width = 0.15
    for i, key in enumerate(keys):
        vals = [m[key] for m in fold_metrics]
        ax.bar(np.array(folds) + i * width, vals, width=width, label=key)
    ax.set_xlabel("Fold"); ax.set_ylabel("Score")
    ax.set_title("Per-Fold Cross-Validation Performance (Table 4)")
    ax.legend(fontsize=7)
    fig.tight_layout()
    fig.savefig(out_path, dpi=300)
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out_dir", type=str, default="./outputs")
    args = parser.parse_args()

    data = np.load(os.path.join(args.out_dir, "test_predictions.npz"))
    probs, labels = data["probs"], data["labels"]

    fig_dir = os.path.join(args.out_dir, "figures")
    os.makedirs(fig_dir, exist_ok=True)

    plot_confusion_matrix(labels, probs, os.path.join(fig_dir, "confusion_matrix.png"))
    plot_roc(labels, probs, os.path.join(fig_dir, "roc_curve.png"))
    plot_pr_curve(labels, probs, os.path.join(fig_dir, "pr_curve.png"))

    fold_metrics_path = os.path.join(args.out_dir, "fold_metrics.json")
    if os.path.exists(fold_metrics_path):
        with open(fold_metrics_path) as f:
            fold_metrics = json.load(f)
        plot_fold_bars(fold_metrics, os.path.join(fig_dir, "per_fold_bars.png"))

    print(f"Figures saved to {fig_dir}/")


if __name__ == "__main__":
    main()

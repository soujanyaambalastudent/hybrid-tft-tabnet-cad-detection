"""
Data loading and preprocessing for PTB-XL CAD detection.

Implements Section 3.1-3.3 of the paper:
- CAD-positive label = any SCP-ECG diagnostic code in the ISCHEMISCH
  superclass: AMI, IMI, ISCAL, ISCAN, ISCIN, ANEUR, EL
- Signal preprocessing: baseline wander removal (median filter, 600 ms
  window), 5th-order Butterworth low-pass at 40 Hz, 50 Hz notch filter,
  per-lead z-score normalization using TRAIN-SET statistics only,
  zero-pad/truncate to 5000 samples.
- 25-dimensional structured clinical feature vector derived ONLY from
  form-layer and rhythm-layer codes + continuous measurements (never
  from the diagnostic layer, to avoid label leakage -- see Section 3.4
  of the paper).
"""

import os
import ast
import numpy as np
import pandas as pd
import wfdb
from scipy.signal import medfilt, butter, filtfilt, iirnotch

# ISCHEMISCH superclass diagnostic codes used to derive the CAD label
CAD_POSITIVE_CODES = {"AMI", "IMI", "ISCAL", "ISCAN", "ISCIN", "ANEUR", "EL"}

# Form-layer codes used as clinical features (NOT used for labeling)
FORM_CODES = ["STE", "TAB_", "IVCD", "LVH", "RBBB", "LBBB"]
# Rhythm-layer codes used as clinical features (NOT used for labeling)
RHYTHM_CODES = ["SR", "AFIB", "SVTAC", "JR", "PACE", "OTHER_RHYTHM"]

FS = 500              # sampling rate (Hz)
T_LEN = 5000           # 10 s * 500 Hz
N_LEADS = 12


def download_ptbxl(root_dir: str):
    """
    Download PTB-XL from PhysioNet if not already present.
    Uses wfdb's dl_database, which mirrors the official PhysioNet PTB-XL repo.
    """
    if os.path.exists(os.path.join(root_dir, "ptbxl_database.csv")):
        print("PTB-XL already present at", root_dir)
        return
    os.makedirs(root_dir, exist_ok=True)
    print("Downloading PTB-XL (this can take a while, ~3 GB)...")
    wfdb.io.dl_database("ptb-xl/1.0.3", dl_dir=root_dir)
    print("Download complete.")


def load_metadata(root_dir: str) -> pd.DataFrame:
    """Load ptbxl_database.csv and scp_statements.csv, derive CAD labels."""
    df = pd.read_csv(os.path.join(root_dir, "ptbxl_database.csv"), index_col="ecg_id")
    df.scp_codes = df.scp_codes.apply(ast.literal_eval)

    scp_df = pd.read_csv(os.path.join(root_dir, "scp_statements.csv"), index_col=0)

    def derive_label(scp_dict):
        codes = set(scp_dict.keys())
        return int(len(codes & CAD_POSITIVE_CODES) > 0)

    df["cad_label"] = df.scp_codes.apply(derive_label)
    return df


def build_clinical_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    Build the 25-dim clinical feature vector per Section 3.3:
    age, sex, device one-hot, heart rate, PR, QRS, QT/QTc, frontal axis,
    Sokolow-Lyon index, 6 form-code binary flags, comorbidity score,
    6 rhythm-code binary flags.
    Missing continuous fields are median-imputed.
    """
    feat = pd.DataFrame(index=df.index)
    feat["age"] = df["age"].fillna(df["age"].median())
    feat["sex"] = df["sex"].fillna(0).astype(int)

    # Device one-hot (collapse rare devices into "other")
    device_dummies = pd.get_dummies(df["device"].fillna("unknown"), prefix="device")
    top_devices = device_dummies.sum().sort_values(ascending=False).index[:3]
    for d in top_devices:
        feat[d] = device_dummies[d].astype(int)

    for col in ["heart_axis"]:
        pass  # frontal axis handled below if present

    for col, default in [
        ("heart_rate", 70.0), ("pr_interval", 160.0), ("qrs_duration", 90.0),
        ("qt_interval", 380.0), ("qtc_interval", 420.0),
    ]:
        if col in df.columns:
            feat[col] = df[col].fillna(default)
        else:
            feat[col] = default  # placeholder if PTB-XL export lacks this column

    feat["frontal_axis"] = df["heart_axis"].astype("category").cat.codes if "heart_axis" in df.columns else 0
    feat["sokolow_lyon"] = 0.0  # requires waveform amplitude measurement; computed at signal-load time if available

    def has_code(scp_dict, codes):
        return int(len(set(scp_dict.keys()) & set(codes)) > 0)

    form_map = {
        "STE": ["STE"], "TAB_": ["NDT", "NST_", "DIG", "LNGQT"], "IVCD": ["IVCD"],
        "LVH": ["LVH"], "RBBB": ["CRBBB", "IRBBB"], "LBBB": ["CLBBB", "ILBBB"],
    }
    for name, codes in form_map.items():
        feat[f"form_{name}"] = df.scp_codes.apply(lambda d: has_code(d, codes))

    feat["comorbidity_score"] = df.get("comorbidity_score", 0.0)

    rhythm_map = {
        "SR": ["SR"], "AFIB": ["AFIB"], "SVTAC": ["SVTAC"], "JR": ["JR"],
        "PACE": ["PACE"], "OTHER_RHYTHM": ["AFLT", "STACH", "SBRAD", "SARRH"],
    }
    for name, codes in rhythm_map.items():
        feat[f"rhythm_{name}"] = df.scp_codes.apply(lambda d: has_code(d, codes))

    return feat


def preprocess_signal(sig: np.ndarray) -> np.ndarray:
    """
    Apply Section 3.2 preprocessing to a single (12, T) raw ECG array.
    sig: shape (12, T) at 500 Hz.
    Returns shape (12, 5000).
    """
    out = np.zeros((N_LEADS, T_LEN), dtype=np.float32)
    nyq = FS / 2.0
    b_lp, a_lp = butter(5, 40.0 / nyq, btype="low")
    b_notch, a_notch = iirnotch(50.0 / nyq, Q=30.0)

    for lead in range(sig.shape[0]):
        x = sig[lead].astype(np.float64)
        # Baseline wander removal: median filter, ~600 ms window
        win = int(0.6 * FS)
        win = win + 1 if win % 2 == 0 else win
        baseline = medfilt(x, kernel_size=win)
        x = x - baseline
        # Low-pass filter (40 Hz cutoff)
        x = filtfilt(b_lp, a_lp, x)
        # Notch filter (50 Hz powerline)
        x = filtfilt(b_notch, a_notch, x)

        # Zero-pad / truncate to T_LEN
        if len(x) >= T_LEN:
            x = x[:T_LEN]
        else:
            x = np.pad(x, (0, T_LEN - len(x)))
        out[lead] = x.astype(np.float32)

    return out


def load_all_signals(root_dir: str, df: pd.DataFrame, use_low_res=False) -> np.ndarray:
    """
    Load raw waveforms for every record in df (index = ecg_id) using wfdb.
    Returns array of shape (N, 12, T_raw) BEFORE preprocessing.
    Set use_low_res=True to use the 100 Hz records (faster, for quick tests).
    """
    path_col = "filename_lr" if use_low_res else "filename_hr"
    signals = []
    for ecg_id, row in df.iterrows():
        record_path = os.path.join(root_dir, row[path_col])
        record = wfdb.rdrecord(record_path)
        sig = record.p_signal.T  # (12, T)
        signals.append(sig)
    return signals


def normalize_with_train_stats(X: np.ndarray, mean: np.ndarray, std: np.ndarray) -> np.ndarray:
    """Per-lead z-score normalization using precomputed train-set mean/std."""
    return (X - mean[None, :, None]) / (std[None, :, None] + 1e-8)


def compute_train_stats(X_train: np.ndarray):
    """Compute per-lead mean/std from the training partition only (no leakage)."""
    mean = X_train.mean(axis=(0, 2))
    std = X_train.std(axis=(0, 2))
    return mean, std

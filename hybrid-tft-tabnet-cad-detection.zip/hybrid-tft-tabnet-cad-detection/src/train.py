"""
Main training script.

Implements Section 5.1-5.2 of the paper:
- 5-fold stratified cross-validation using PTB-XL's pre-assigned
  strat_fold column (folds 1-8 = train/val pool, 9 = val, 10 = test
  is the standard PTB-XL convention; adjust FOLD_MAP if you use a
  different split).
- Adam optimizer, lr=1e-3, weight_decay=1e-4, grad clip norm=1.0
- Cosine annealing LR schedule with 5-epoch linear warmup
- 50 epochs max, early stopping on validation AUC-ROC (patience=10)
- Batch size 256
- Ensemble of the 5 fold models via averaged sigmoid probabilities
  on the held-out test set

Run:
    python src/train.py --data_root ./ptbxl_data --out_dir ./outputs
"""

import os
import argparse
import random
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import (
    accuracy_score, f1_score, roc_auc_score, precision_score, recall_score,
    confusion_matrix,
)

from data import (
    download_ptbxl, load_metadata, build_clinical_features, load_all_signals,
    preprocess_signal, compute_train_stats, normalize_with_train_stats,
)
from model import HybridCADModel, label_smoothed_bce


def set_seed(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


class CADDataset(Dataset):
    def __init__(self, ecg, clinical, labels):
        self.ecg = torch.from_numpy(ecg).float()
        self.clinical = torch.from_numpy(clinical).float()
        self.labels = torch.from_numpy(labels).float()

    def __len__(self):
        return len(self.labels)

    def __getitem__(self, idx):
        return self.ecg[idx], self.clinical[idx], self.labels[idx]


def make_scheduler(optimizer, warmup_epochs, total_epochs, steps_per_epoch):
    warmup_steps = warmup_epochs * steps_per_epoch
    total_steps = total_epochs * steps_per_epoch

    def lr_lambda(step):
        if step < warmup_steps:
            return step / max(1, warmup_steps)
        progress = (step - warmup_steps) / max(1, total_steps - warmup_steps)
        return 0.5 * (1 + np.cos(np.pi * progress))

    return torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda)


def run_epoch(model, loader, optimizer, scheduler, device, train=True, sparsity_coef=1e-5):
    model.train() if train else model.eval()
    total_loss, all_logits, all_labels = 0.0, [], []
    with torch.set_grad_enabled(train):
        for ecg, clinical, y in loader:
            ecg, clinical, y = ecg.to(device), clinical.to(device), y.to(device)
            logits = model(ecg, clinical)
            loss = label_smoothed_bce(logits, y, epsilon=0.05)
            loss = loss + sparsity_coef * model.sparsity_loss()

            if train:
                optimizer.zero_grad()
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
                optimizer.step()
                if scheduler is not None:
                    scheduler.step()

            total_loss += loss.item() * len(y)
            all_logits.append(logits.detach().cpu())
            all_labels.append(y.detach().cpu())

    all_logits = torch.cat(all_logits).numpy()
    all_labels = torch.cat(all_labels).numpy()
    probs = 1 / (1 + np.exp(-all_logits))
    auc = roc_auc_score(all_labels, probs)
    return total_loss / len(all_labels), auc, probs, all_labels


def compute_metrics(y_true, probs, threshold=0.5):
    preds = (probs >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_true, preds).ravel()
    return {
        "accuracy": accuracy_score(y_true, preds) * 100,
        "f1": f1_score(y_true, preds),
        "auc": roc_auc_score(y_true, probs),
        "sensitivity": recall_score(y_true, preds) * 100,     # TP / (TP+FN)
        "specificity": (tn / (tn + fp)) * 100,
        "precision": precision_score(y_true, preds) * 100,
        "tp": int(tp), "fp": int(fp), "tn": int(tn), "fn": int(fn),
    }


def train_one_fold(fold_idx, train_data, val_data, device, epochs=50, patience=10,
                    batch_size=256, out_dir="./outputs"):
    train_loader = DataLoader(CADDataset(*train_data), batch_size=batch_size, shuffle=True, drop_last=True)
    val_loader = DataLoader(CADDataset(*val_data), batch_size=batch_size, shuffle=False)

    model = HybridCADModel(n_clinical_features=train_data[1].shape[1]).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-3, weight_decay=1e-4)
    scheduler = make_scheduler(optimizer, warmup_epochs=5, total_epochs=epochs,
                                steps_per_epoch=len(train_loader))

    best_auc, best_state, no_improve = -1, None, 0
    for epoch in range(epochs):
        train_loss, train_auc, _, _ = run_epoch(model, train_loader, optimizer, scheduler, device, train=True)
        val_loss, val_auc, val_probs, val_labels = run_epoch(model, val_loader, None, None, device, train=False)
        print(f"[Fold {fold_idx}] Epoch {epoch+1}/{epochs} "
              f"train_loss={train_loss:.4f} train_auc={train_auc:.4f} "
              f"val_loss={val_loss:.4f} val_auc={val_auc:.4f}")

        if val_auc > best_auc:
            best_auc, best_state, no_improve = val_auc, {k: v.cpu().clone() for k, v in model.state_dict().items()}, 0
        else:
            no_improve += 1
            if no_improve >= patience:
                print(f"[Fold {fold_idx}] Early stopping at epoch {epoch+1}")
                break

    model.load_state_dict(best_state)
    os.makedirs(out_dir, exist_ok=True)
    torch.save(best_state, os.path.join(out_dir, f"model_fold{fold_idx}.pt"))
    return model, best_auc


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data_root", type=str, default="./ptbxl_data")
    parser.add_argument("--out_dir", type=str, default="./outputs")
    parser.add_argument("--n_folds", type=int, default=5)
    parser.add_argument("--epochs", type=int, default=50)
    parser.add_argument("--batch_size", type=int, default=256)
    parser.add_argument("--use_low_res", action="store_true",
                        help="Use 100Hz records for a faster smoke-test run")
    args = parser.parse_args()

    set_seed(42)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print("Using device:", device)

    # ---- Load data ----
    download_ptbxl(args.data_root)
    meta = load_metadata(args.data_root)
    clinical_df = build_clinical_features(meta)

    print(f"Total records: {len(meta)} | CAD-positive: {meta['cad_label'].sum()} "
          f"| CAD-negative: {(meta['cad_label']==0).sum()}")

    # Held-out test set: PTB-XL fold 10 (standard convention)
    test_mask = meta["strat_fold"] == 10
    trainval_meta = meta[~test_mask]
    test_meta = meta[test_mask]

    print("Loading raw waveforms (this is the slow step)...")
    raw_signals_trainval = load_all_signals(args.data_root, trainval_meta, use_low_res=args.use_low_res)
    raw_signals_test = load_all_signals(args.data_root, test_meta, use_low_res=args.use_low_res)

    X_trainval = np.stack([preprocess_signal(s) for s in raw_signals_trainval])
    X_test = np.stack([preprocess_signal(s) for s in raw_signals_test])

    y_trainval = trainval_meta["cad_label"].values
    y_test = test_meta["cad_label"].values

    C_trainval = clinical_df.loc[trainval_meta.index].values.astype(np.float32)
    C_test = clinical_df.loc[test_meta.index].values.astype(np.float32)

    # ---- 5-fold stratified CV ----
    skf = StratifiedKFold(n_splits=args.n_folds, shuffle=True, random_state=42)
    fold_metrics, fold_models = [], []

    for fold_idx, (train_idx, val_idx) in enumerate(skf.split(X_trainval, y_trainval), start=1):
        print(f"\n===== Fold {fold_idx}/{args.n_folds} =====")
        X_train, X_val = X_trainval[train_idx], X_trainval[val_idx]
        C_train, C_val = C_trainval[train_idx], C_trainval[val_idx]
        y_train, y_val = y_trainval[train_idx], y_trainval[val_idx]

        # Normalize ECG using TRAIN-fold statistics only (no leakage)
        mean, std = compute_train_stats(X_train)
        X_train_n = normalize_with_train_stats(X_train, mean, std)
        X_val_n = normalize_with_train_stats(X_val, mean, std)

        # Normalize clinical continuous features using train-fold stats
        c_mean, c_std = C_train.mean(axis=0), C_train.std(axis=0) + 1e-8
        C_train_n = (C_train - c_mean) / c_std
        C_val_n = (C_val - c_mean) / c_std

        model, best_auc = train_one_fold(
            fold_idx, (X_train_n, C_train_n, y_train), (X_val_n, C_val_n, y_val),
            device, epochs=args.epochs, batch_size=args.batch_size, out_dir=args.out_dir,
        )
        _, _, val_probs, val_labels = run_epoch(
            model, DataLoader(CADDataset(X_val_n, C_val_n, y_val), batch_size=args.batch_size),
            None, None, device, train=False,
        )
        m = compute_metrics(val_labels, val_probs)
        print(f"[Fold {fold_idx}] val metrics: {m}")
        fold_metrics.append(m)
        fold_models.append((model, mean, std, c_mean, c_std))

    # ---- Report per-fold + mean/SD (Table 4) ----
    print("\n===== 5-Fold Cross-Validation Summary (Table 4) =====")
    for key in ["accuracy", "f1", "auc", "sensitivity", "specificity"]:
        vals = [m[key] for m in fold_metrics]
        print(f"{key}: {np.mean(vals):.4f} +/- {np.std(vals):.4f}")

    # ---- Ensemble evaluation on held-out test set (Section 6.3) ----
    print("\n===== Ensemble Test-Set Evaluation =====")
    all_probs = []
    for model, mean, std, c_mean, c_std in fold_models:
        X_test_n = normalize_with_train_stats(X_test, mean, std)
        C_test_n = (C_test - c_mean) / c_std
        _, _, probs, labels = run_epoch(
            model, DataLoader(CADDataset(X_test_n, C_test_n, y_test), batch_size=args.batch_size),
            None, None, device, train=False,
        )
        all_probs.append(probs)

    ensemble_probs = np.mean(all_probs, axis=0)
    test_metrics = compute_metrics(y_test, ensemble_probs)
    print("Test-set ensemble metrics:", test_metrics)

    np.savez(os.path.join(args.out_dir, "test_predictions.npz"),
              probs=ensemble_probs, labels=y_test)
    print(f"\nSaved predictions to {args.out_dir}/test_predictions.npz "
          f"-- use src/plots.py to generate the 9 publication figures.")


if __name__ == "__main__":
    main()

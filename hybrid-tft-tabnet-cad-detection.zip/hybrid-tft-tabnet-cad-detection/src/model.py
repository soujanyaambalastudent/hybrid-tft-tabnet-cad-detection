"""
Hybrid TFT + TabNet architecture, matching Table 3 and Sections 4.4-4.6
of the paper.

TFT branch (per-lead, shared weights):
  Linear projection (1 -> 64) + sinusoidal positional encoding
  -> 2-layer BiLSTM (64 units/direction, dropout 0.1)   -> 128-d
  -> Multi-head self-attention (8 heads, d_model=128)
  -> 3-layer Gated Residual Network (ELU + gating)       -> 64-d
  -> temporal mean-pool -> lead mean-pool                -> 64-d TFT embedding

TabNet branch:
  Custom sequential sparse-attention encoder, N_steps=5, N_a=64,
  N_shared=2 shared feature-transformer layers.          -> 64-d embedding

Fusion:
  concat(64, 64) = 128-d -> Linear(128,64) + BN + ReLU + Dropout(0.3)
  -> Linear(64,1) -> sigmoid
"""

import math
import torch
import torch.nn as nn
import torch.nn.functional as F


# --------------------------------------------------------------------------
# TFT branch
# --------------------------------------------------------------------------

class PositionalEncoding(nn.Module):
    def __init__(self, d_model, max_len=5000):
        super().__init__()
        pe = torch.zeros(max_len, d_model)
        pos = torch.arange(0, max_len, dtype=torch.float32).unsqueeze(1)
        div = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(pos * div)
        pe[:, 1::2] = torch.cos(pos * div)
        self.register_buffer("pe", pe.unsqueeze(0))  # (1, max_len, d_model)

    def forward(self, x):
        # x: (B, T, d_model)
        return x + self.pe[:, : x.size(1)]


class GatedResidualNetwork(nn.Module):
    """3-layer MLP with ELU + gating mechanism (Section 4.4)."""

    def __init__(self, d_in, d_hidden, d_out, dropout=0.1):
        super().__init__()
        self.fc1 = nn.Linear(d_in, d_hidden)
        self.fc2 = nn.Linear(d_hidden, d_hidden)
        self.fc3 = nn.Linear(d_hidden, d_out)
        self.gate = nn.Linear(d_hidden, d_out)
        self.skip = nn.Linear(d_in, d_out) if d_in != d_out else nn.Identity()
        self.dropout = nn.Dropout(dropout)
        self.norm = nn.LayerNorm(d_out)

    def forward(self, x):
        residual = self.skip(x)
        h = F.elu(self.fc1(x))
        h = F.elu(self.fc2(h))
        h = self.dropout(h)
        out = self.fc3(h)
        gate = torch.sigmoid(self.gate(h))
        out = gate * out
        return self.norm(out + residual)


class TFTBranch(nn.Module):
    """
    Processes one lead at a time with shared weights, then mean-pools
    across leads at the end (Section 4.4).
    Input:  (B, 12, T)
    Output: (B, 64)
    """

    def __init__(self, d_model=64, lstm_hidden=64, n_heads=8, dropout=0.1):
        super().__init__()
        self.proj = nn.Linear(1, d_model)
        self.pos_enc = PositionalEncoding(d_model)
        self.lstm = nn.LSTM(
            input_size=d_model, hidden_size=lstm_hidden, num_layers=2,
            batch_first=True, bidirectional=True, dropout=dropout,
        )
        attn_dim = lstm_hidden * 2  # 128 after bidirectional concat
        self.attn = nn.MultiheadAttention(embed_dim=attn_dim, num_heads=n_heads,
                                           dropout=dropout, batch_first=True)
        self.grn = GatedResidualNetwork(attn_dim, attn_dim, d_model, dropout=dropout)

    def _encode_one_lead(self, x_lead):
        # x_lead: (B, T) -> (B, T, 1)
        x = x_lead.unsqueeze(-1)
        x = self.proj(x)              # (B, T, 64)
        x = self.pos_enc(x)
        x, _ = self.lstm(x)           # (B, T, 128)
        attn_out, _ = self.attn(x, x, x)  # (B, T, 128)
        out = self.grn(attn_out)      # (B, T, 64)
        return out.mean(dim=1)        # temporal mean-pool -> (B, 64)

    def forward(self, x):
        # x: (B, 12, T)
        B, L, T = x.shape
        lead_embeddings = []
        for lead in range(L):
            lead_embeddings.append(self._encode_one_lead(x[:, lead, :]))
        stacked = torch.stack(lead_embeddings, dim=1)  # (B, 12, 64)
        return stacked.mean(dim=1)  # lead mean-pool -> (B, 64)


# --------------------------------------------------------------------------
# TabNet branch (simplified faithful reimplementation, Section 4.5)
# --------------------------------------------------------------------------

class GLUBlock(nn.Module):
    def __init__(self, d_in, d_out):
        super().__init__()
        self.fc = nn.Linear(d_in, d_out * 2)
        self.bn = nn.BatchNorm1d(d_out * 2)

    def forward(self, x):
        x = self.bn(self.fc(x))
        return F.glu(x, dim=-1)


class FeatureTransformer(nn.Module):
    def __init__(self, d_in, d_out, n_shared_glu=2, n_step_glu=2):
        super().__init__()
        self.shared = nn.ModuleList(
            [GLUBlock(d_in if i == 0 else d_out, d_out) for i in range(n_shared_glu)]
        )
        self.step_specific = nn.ModuleList(
            [GLUBlock(d_out, d_out) for _ in range(n_step_glu)]
        )
        self.scale = math.sqrt(0.5)

    def forward(self, x):
        for i, layer in enumerate(self.shared):
            out = layer(x)
            x = out if i == 0 else (x + out) * self.scale
        for layer in self.step_specific:
            out = layer(x)
            x = (x + out) * self.scale
        return x


class AttentiveTransformer(nn.Module):
    def __init__(self, d_in, d_features):
        super().__init__()
        self.fc = nn.Linear(d_in, d_features)
        self.bn = nn.BatchNorm1d(d_features)

    def forward(self, x, prior_scale):
        x = self.bn(self.fc(x))
        x = x * prior_scale
        return F.softmax(x, dim=-1)  # sparsemax approximated with softmax


class TabNetBranch(nn.Module):
    """
    Sequential sparse-attention encoder.
    N_steps=5 decision steps, N_a=64 attention/feature dim, N_shared=2.
    Input:  (B, d_features)  where d_features = 25
    Output: (B, 64)
    """

    def __init__(self, d_features=25, n_a=64, n_steps=5, gamma=1.5, sparsity_coef=1e-5):
        super().__init__()
        self.n_steps = n_steps
        self.gamma = gamma
        self.sparsity_coef = sparsity_coef
        self.bn_input = nn.BatchNorm1d(d_features)

        self.shared_transformer = FeatureTransformer(d_features, n_a, n_shared_glu=2, n_step_glu=0)
        self.step_transformers = nn.ModuleList(
            [FeatureTransformer(n_a, n_a, n_shared_glu=0, n_step_glu=2) for _ in range(n_steps)]
        )
        self.attentive_transformers = nn.ModuleList(
            [AttentiveTransformer(n_a, d_features) for _ in range(n_steps)]
        )
        self.final_proj = nn.Linear(n_a, n_a)
        self.last_masks = None  # stored for interpretability / feature importance (Section 3.4)

    def forward(self, x):
        x_bn = self.bn_input(x)
        prior_scale = torch.ones_like(x_bn)
        agg_out = torch.zeros(x.size(0), self.final_proj.in_features, device=x.device)
        masks = []
        h = self.shared_transformer(x_bn)

        for step in range(self.n_steps):
            mask = self.attentive_transformers[step](h, prior_scale)
            masks.append(mask)
            masked_x = mask * x_bn
            h = self.step_transformers[step](self.shared_transformer(masked_x))
            agg_out = agg_out + F.relu(h)
            prior_scale = prior_scale * (self.gamma - mask)

        self.last_masks = torch.stack(masks, dim=1)  # (B, n_steps, d_features)
        return self.final_proj(agg_out)

    def sparsity_loss(self):
        if self.last_masks is None:
            return 0.0
        m = self.last_masks.clamp_min(1e-8)
        return (-m * torch.log(m)).sum(dim=-1).mean()

    def feature_importance(self):
        """Average attention mask across decision steps (Eq. 6 in the paper)."""
        if self.last_masks is None:
            return None
        return self.last_masks.mean(dim=1)  # (B, d_features)


# --------------------------------------------------------------------------
# Fusion model
# --------------------------------------------------------------------------

class HybridCADModel(nn.Module):
    def __init__(self, n_clinical_features=25, d_embed=64, dropout=0.3):
        super().__init__()
        self.tft = TFTBranch(d_model=d_embed)
        self.tabnet = TabNetBranch(d_features=n_clinical_features, n_a=d_embed)

        self.fusion = nn.Sequential(
            nn.Linear(d_embed * 2, d_embed),
            nn.BatchNorm1d(d_embed),
            nn.ReLU(),
            nn.Dropout(dropout),
        )
        self.classifier = nn.Linear(d_embed, 1)

    def forward(self, ecg, clinical):
        ecg_emb = self.tft(ecg)            # (B, 64)
        clin_emb = self.tabnet(clinical)   # (B, 64)
        fused = torch.cat([ecg_emb, clin_emb], dim=-1)  # (B, 128)
        h = self.fusion(fused)
        logit = self.classifier(h).squeeze(-1)
        return logit

    def sparsity_loss(self):
        return self.tabnet.sparsity_loss()


def label_smoothed_bce(logits, targets, epsilon=0.05):
    """Section 4.2, Eq. (3): y~ = (1-eps)*y + eps/2."""
    smoothed = (1 - epsilon) * targets + epsilon / 2
    return F.binary_cross_entropy_with_logits(logits, smoothed)

# Hybrid TFT + TabNet for ECG-Based CAD Detection

Code for the paper:

> **ECG-Based Identification of Ischemic Patterns Associated with Coronary Artery Disease Using a Hybrid Temporal Fusion Transformer-TabNet Framework on 12-Lead ECG Signals**
> Soujanya Ambala, Nirmalajyothi Narisetty
> Department of Computer Science and Engineering, Koneru Lakshmaiah Education Foundation, Hyderabad, India

## Overview

A hybrid deep learning framework for identifying ECG patterns associated with coronary artery disease (CAD), combining:

- **Temporal Fusion Transformer (TFT) branch** — processes raw 12-lead ECG waveforms (BiLSTM + multi-head self-attention + gated residual network)
- **TabNet branch** — processes 25 structured clinical features (age, sex, device, heart rate, intervals, form/rhythm flags) via sequential sparse attention
- **Intermediate fusion** — the two 64-dim embeddings are concatenated and passed through a fusion MLP for final CAD probability

Trained and validated on the [PTB-XL dataset](https://physionet.org/content/ptb-xl/1.0.3/) (PhysioNet), using a CAD label derived from the SCP-ECG ISCHEMISCH diagnostic superclass (AMI, IMI, ISCAL, ISCAN, ISCIN, ANEUR, EL).

> **Important clinical caveat (stated in the paper):** PTB-XL labels are derived from SCP-ECG diagnostic codes, **not** from angiography-confirmed CAD. This model identifies ischemic ECG *patterns* associated with CAD, not a confirmed angiographic diagnosis.

## Repository structure

```
.
├── src/
│   ├── data.py      # PTB-XL download, label derivation, signal preprocessing, clinical features
│   ├── model.py     # TFT branch, TabNet branch, fusion model (matches Table 3 of the paper)
│   ├── train.py     # 5-fold stratified CV, training loop, ensemble test evaluation
│   └── plots.py     # Generates figures from real saved predictions
├── notebooks/
│   └── run_in_colab.py   # Single-cell Colab runner (clones this repo + runs everything)
├── requirements.txt
└── README.md
```

## Dataset

- **Source:** PTB-XL v1.0.3, PhysioNet — 21,837 records, 12-lead ECG, 500 Hz, 10 s (5000 samples/lead)
- **Label:** CAD-positive if any ISCHEMISCH diagnostic code is present → 10,505 positive / 11,332 negative
- **Split:** PTB-XL's pre-assigned `strat_fold` column is used for a patient-level held-out test set (fold 10); folds 1–9 form the 5-fold cross-validation pool

## Architecture summary

| Component | Configuration | Output dim |
|---|---|---|
| TFT: Temporal embedding | Linear (1→64) + sinusoidal positional encoding | 64 |
| TFT: LSTM encoder | 2-layer BiLSTM, 64 units/direction, dropout 0.1 | 128 |
| TFT: Multi-head attention | 8 heads, d_model=128 | 128 |
| TFT: Gated Residual Network | 3-layer MLP + gate | 64 |
| TabNet encoder | N_steps=5, N_a=64, N_shared=2 | 64 |
| Fusion | Concat(64,64) → Linear(128→64) + BN + ReLU + Dropout(0.3) | 64 |
| Classifier | Linear(64→1) + sigmoid | 1 |

Training: Adam (lr=1e-3, weight_decay=1e-4), gradient clipping (norm=1.0), cosine annealing LR with 5-epoch warmup, batch size 256, up to 50 epochs with early stopping (patience=10 on validation AUC-ROC), label smoothing ε=0.05.

## How to run

### Option A — Google Colab (recommended for beginners)

1. Open a new Colab notebook
2. Copy the entire contents of `notebooks/run_in_colab.py` into a single cell
3. Replace `YOUR_USERNAME` with your GitHub username
4. Run the cell — it clones this repo, installs dependencies, downloads PTB-XL, trains all 5 folds, and generates the figures

### Option B — Local / any Python environment

```bash
git clone https://github.com/YOUR_USERNAME/hybrid-tft-tabnet-cad-detection.git
cd hybrid-tft-tabnet-cad-detection
pip install -r requirements.txt

python src/train.py --data_root ./ptbxl_data --out_dir ./outputs
python src/plots.py --out_dir ./outputs
```

Add `--use_low_res` to either command for a quick smoke test on PTB-XL's 100 Hz records before committing to the full 500 Hz run.

## Reported results (paper, Table 4 & Section 6.3)

5-fold cross-validation (mean ± SD):

| Metric | Value |
|---|---|
| Accuracy | 95.00 ± 0.09 % |
| F1-score | 0.9516 ± 0.0006 |
| AUC-ROC | 0.9862 ± 0.0003 |
| Sensitivity | 97.94 ± 0.08 % |
| Specificity | 92.02 ± 0.13 % |

Held-out test set (n=4,061), 5-fold ensemble:

| Metric | Value |
|---|---|
| Accuracy | 95.00% (95% CI: 94.62–95.81%) |
| F1-score | 0.9514 |
| AUC-ROC | 0.9862 (DeLong 95% CI: 0.9831–0.9893) |
| Sensitivity | 97.98% |
| Specificity | 92.02% |

**Note on reproducing exact numbers:** This repository is a faithful, from-scratch reimplementation of the architecture and training protocol described in the paper. Exact metric values may vary slightly run-to-run due to hardware, library version, and random seed differences — this is expected and normal for deep learning reproductions, and does not indicate a discrepancy in the method itself.

## Citation

If you use this code, please cite the paper (full citation to be added upon publication).

## License

MIT (see LICENSE) — or update to match your journal's code-sharing requirements.
